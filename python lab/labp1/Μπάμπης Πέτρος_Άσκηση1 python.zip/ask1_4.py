str1 = input("Type string: ")
s1 = str1[0]
s2 = str1[int(len(str1)/2)]
s3 = str1[-1]

s_result = s1+s2+s3
print(s_result)
