m = input("Type a number m: ")
s1 = m
s2 = m + m
s3 = m + m + m
print("Result", s1,  "+", s2, "+" , s3, "=", int(int(m) + int(s2) + int(s3)))
