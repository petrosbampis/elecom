inches = float(input("Type measurement in inches: "))
cm = inches*2.54
print("Measurement in inches is: ", inches)
print("Measurement in cm is: ", cm)