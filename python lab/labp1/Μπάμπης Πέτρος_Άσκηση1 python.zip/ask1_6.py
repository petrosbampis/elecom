s = input("Type string: ")
print("String in reverse:", s[::-1])
