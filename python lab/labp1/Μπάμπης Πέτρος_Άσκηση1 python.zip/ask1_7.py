n1 = float(input("Type number 1: "))
n2 = float(input("Type number 2: "))
n3 = float(input("Type number 3: "))

print("The avg value is: ", (n1+n2+n3)/3)