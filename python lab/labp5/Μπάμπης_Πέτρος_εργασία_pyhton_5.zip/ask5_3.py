squares_dict = {key: key**2 for key in range(1, 16)}

print("Generated Dictionary:")
print(squares_dict)