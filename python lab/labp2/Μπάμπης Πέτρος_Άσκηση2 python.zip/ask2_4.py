i = 1
print("Odd numbers from 1 to 500:")
while i<=500:
    if i%2 != 0:
        print(i)
    i += 1